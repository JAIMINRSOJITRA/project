export const products = [
  {
    id: 1,
    name: "Classic White T-Shirt",
    price: 599,
    category: "t-shirts",
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500",
    description: "Premium cotton classic white t-shirt with a comfortable fit"
  },
  {
    id: 2,
    name: "Slim Fit Blue Jeans",
    price: 1499,
    category: "jeans",
    image: "https://images.unsplash.com/photo-1542272604-787c3835535d?w=500",
    description: "Stylish slim-fit jeans in classic blue denim"
  },
  {
    id: 3,
    name: "Black Hoodie",
    price: 999,
    category: "hoodies",
    image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=500",
    description: "Comfortable black hoodie perfect for casual wear"
  },
  {
    id: 4,
    name: "Traditional Kurta",
    price: 1299,
    category: "kurtas",
    image: "https://images.unsplash.com/photo-1597983073493-88cd35cf93b0?w=500",
    description: "Elegant traditional kurta with detailed embroidery"
  },
  {
    id: 5,
    name: "Formal White Shirt",
    price: 899,
    category: "shirts",
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500",
    description: "Crisp white formal shirt for professional occasions"
  },
  {
    id: 6,
    name: "Designer Denim Jacket",
    price: 2499,
    category: "jackets",
    image: "https://images.unsplash.com/photo-1551537482-f2075a1d41f2?w=500",
    description: "Stylish denim jacket perfect for casual outings"
  },
  {
    id: 7,
    name: "Premium Track Pants",
    price: 899,
    category: "pants",
    image: "https://images.unsplash.com/photo-1552902865-b72c031ac5ea?w=500",
    description: "Comfortable track pants for sports and casual wear"
  },
  {
    id: 8,
    name: "Ethnic Embroidered Kurta",
    price: 1899,
    category: "kurtas",
    image: "https://images.unsplash.com/photo-1597983072945-944b5fb3ad03?w=500",
    description: "Traditional kurta with intricate embroidery work"
  },
  {
    id: 9,
    name: "Casual Polo T-Shirt",
    price: 799,
    category: "t-shirts",
    image: "https://images.unsplash.com/photo-1586363104862-3a5e2ab60d99?w=500",
    description: "Classic polo t-shirt for a smart casual look"
  },
  {
    id: 10,
    name: "Slim Fit Chinos",
    price: 1299,
    category: "pants",
    image: "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=500",
    description: "Versatile chinos perfect for any occasion"
  }
] as const;